const { getSiteFetcher } = require('./modules/fetcher');
const { logInfo, logError } = require('./utils/logger');
const { loadConfig } = require('../config/loader');
const ErrorHandler = require('./modules/error_handler');
const { saveUrlList } = require('./utils/file_utils');

const config = loadConfig();
const errorHandler = new ErrorHandler(config.paths.logsDir);

(async () => {
  try {
    const targetUrl = process.argv[2];
    const maxPages = parseInt(process.argv[3], 10) || null;

    if (!targetUrl) {
      throw new Error('Target URL is required as the first argument.');
    }

    logInfo('WebArchiver started');
    logInfo(`Target URL: ${targetUrl}`);
    logInfo(`Max Pages: ${maxPages || 'Unlimited'}`);

    const fetchSiteUrls = getSiteFetcher(targetUrl);
    if (!fetchSiteUrls) {
      throw new Error('No valid fetch function returned by getSiteFetcher');
    }

    const urls = await fetchSiteUrls(targetUrl, maxPages);
    logInfo(`Fetched ${urls.length} URLs`);

    const outputDir = config.paths.outputDir;
    const urlListPath = `${outputDir}/urlList.txt`;
    saveUrlList(urlListPath, urls);
    logInfo(`Saved URL list to: ${urlListPath}`);
  } catch (error) {
    errorHandler.handleCriticalError(error);
  }
})();
