const { fetchTicketJamUrls } = require('../sites/ticketjam');
const { fetchTicketCoUrls } = require('../sites/ticketco');

/**
 * サイトに応じたURLフェッチャーを返す
 * @param {string} targetUrl
 * @returns {Function|null}
 */
const getSiteFetcher = (targetUrl) => {
  if (targetUrl.includes('ticketjam.jp')) {
    return fetchTicketJamUrls;
  } else if (targetUrl.includes('ticket.co.jp')) {
    return fetchTicketCoUrls;
  }
  return null; // サポート外のサイトの場合
};

module.exports = { getSiteFetcher };
